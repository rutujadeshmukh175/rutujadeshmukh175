package com.powerfitness.gymregrestapis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymregRestApisApplicationTests {

	@Test
	void contextLoads() {
	}

}
