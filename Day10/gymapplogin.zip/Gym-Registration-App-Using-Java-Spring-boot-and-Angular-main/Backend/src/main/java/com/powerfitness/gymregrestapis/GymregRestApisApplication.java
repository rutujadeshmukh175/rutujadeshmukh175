package com.powerfitness.gymregrestapis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GymregRestApisApplication {

	public static void main(String[] args) {
		SpringApplication.run(GymregRestApisApplication.class, args);
	}

}
